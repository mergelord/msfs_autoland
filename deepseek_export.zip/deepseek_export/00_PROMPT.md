# Code Review Request — MSFS AutoLand (Microsoft Flight Simulator Autoland System)

## Context
Hobby flight simulator autoland system written in Python 3.13. Uses SimConnect to read telemetry from MSFS and send control commands. The system performs automatic approach (final descent on ILS/VOR/NDB), flare (pitch-up at 50ft AGL), and touchdown.

**Status:** Functional skeleton complete, but **ZERO actual approaches have been flown** — only MSFS connection, aircraft detection, and module imports tested.

**Total:** 41 modules, ~20,000 LOC, 1 commit per ~2 hours over Apr 16-22 timeframe.

## What I Already Found (and Fixed in batch 1)
See `batch1_fixes.diff` for already-applied patches and `batch1_README.md` for explanation.

Already fixed (do not repeat these):
1. CRITICAL: `FlareConfig` dataclass non-default-after-default (TypeError on import)
2. HIGH: main.py silent stop_approach on ANY exception → added retry + audio alert
3. HIGH: autothrottle missing airspeed → max throttle bug (PID kicks)
4. HIGH: autothrottle hardcoded `flaps_position=3, gear_down=True` → now reads from telemetry
5. MEDIUM: `"%s%"` format strings in 4 places → ValueError on every log
6. MEDIUM: SimConnect spam in flap/gear deployment (every 0.5s cycle)
7. MEDIUM: KeyError risk on `throttle_data['is_stable']` → use `.get()`
8. MEDIUM: stabilized_approach + LandingPhase fragile dict access → defensive .get()

## What I Want From You

Please perform an independent code review focused on **finding what I missed**. Specifically:

### 1. Safety-Critical Bugs (HIGHEST PRIORITY)
- Edge cases in math (division by zero, off-by-one, sign errors)
- Race conditions between GUI thread and approach control thread
- State machine transitions that could deadlock or skip critical phases
- Sensor fusion issues (when multiple data sources disagree)
- Unit conversion errors (knots vs ft/min, degrees vs radians, ft vs meters)

### 2. Dead Code Paths (UNTESTED — NEVER EXECUTED)
The user has only tested telemetry/aircraft detection. The following modules have NEVER run their main code paths:
- `modules/approach_phases.py` (state machine)
- `modules/autothrottle.py` (PID controller)
- `modules/flare_controller.py` (flare PD controller)
- `modules/wind_correction.py` (drift/crab angle)
- `modules/engine_failure_detector.py`
- `modules/dme_navigation.py`
- `modules/wind_shear_detector.py` / `modules/turbulence_detector.py`

Look hard at these — likely contain silent bugs (wrong formulas, wrong defaults, wrong assumptions).

### 3. Architectural Issues
- Cyclical imports (architecture test claims none — verify)
- Mixing concerns (config + business logic together?)
- Missing error propagation paths (errors swallowed silently)
- Singletons that should be DI

### 4. Specific Code Smells (Skip Unless Important)
- Don't waste time on cosmetic linting (245 prospector issues already known)
- Don't suggest writing tests (deferred decision)
- Don't suggest gui.py refactoring (deferred)
- Focus on **functional correctness** of the autoland logic

## Output Format

For each issue, please provide:

```
### Issue: [Short title]
**Severity:** CRITICAL / HIGH / MEDIUM / LOW
**File:** path/to/file.py:line_number
**Category:** Math / State / Concurrency / Resource / Logic / Other
**Description:** What is wrong
**Failure Mode:** What happens at runtime (be specific)
**Fix:** Proposed minimal change
```

Group findings by severity. CRITICAL/HIGH first, MEDIUM/LOW grouped together.

## Files Provided

- `01_main.py` — entry point, control loop
- `02_modules_*.py` — all flight control modules
- `99_config_thresholds.json` — centralized config
- `batch1_fixes.diff` — patches I already applied
- `batch1_README.md` — explanation of those patches

