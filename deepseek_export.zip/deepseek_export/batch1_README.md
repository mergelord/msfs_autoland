# MSFS AutoLand — Batch 1 Fix Bundle

**Дата:** 2026-04-25
**Базовый коммит:** `d92a7d4` (Добавлена координированная компенсация при асимметричной тяге)
**Метод доставки:** `git apply all_fixes.patch`

## Применение

```powershell
cd C:\BAT\msfs_autoland
git apply C:\path\to\all_fixes.patch
# Проверка после применения:
python -c "from modules.flare_controller import FlareController; print('OK')"
python -c "import main; print('main OK')"
```

Если есть локальные изменения которые конфликтуют — откатить через `git checkout -- <file>` или закоммитить их сначала.

## Что исправлено (7 файлов, +143/-39 строк)

### CRITICAL — блокировал любой запуск

#### 1. `modules/flare_controller.py:15-46` — TypeError на импорте
**Причина:** В dataclass `FlareConfig` non-default поле `throttle_reduction_start` стояло после default-полей `initial_vs`/`target_vs`. Python 3.10+ это запрещает.

**Симптом:**
```
TypeError: non-default argument 'throttle_reduction_start' follows default argument 'target_vs'
```

**Введён в коммите:** `ae07ebc` "Исправлен линтинг и добавлено кэширование Navigraph" (ирония — линт-фикс сломал импорт).

**Фикс:** Переупорядочены поля dataclass — все non-default сверху, все default снизу. Поведение неизменно.

---

### HIGH — некорректная работа на финале захода

#### 2. `main.py:475-521` — Silent stop_approach при любой ошибке
**До:**
```python
except Exception as e:
    logger.error("Error in approach execution: %s", e)
    self.stop_approach()
```
Любая transient ошибка SimConnect (один кадр телеметрии не пришёл, race condition) → autoland тихо отключается на финале без предупреждения пилоту.

**После:**
- `logger.exception()` вместо `logger.error()` — полный traceback в логе
- Звуковой alert (SINK_RATE) если audio system доступен
- Retry до 3 подряд ошибок с backoff в 1s — transient glitch не обрывает заход
- KeyboardInterrupt отдельно — не считается как ошибка

#### 3. `modules/autothrottle.py:241-278` — `[KeyError]` + max throttle на missing data
**Проблема (двойная):**
1. `current_speed = telemetry['speed'].get('airspeed_indicated', 0)` — если airspeed missing, default 0 → PID error = target_speed - 0 = +140kt → **MAX THROTTLE**
2. `flaps_position = 3` и `gear_down = True` хардкод (TODO в коде) — autothrottle думает что гарантированно посадочная конфигурация

**Фикс:**
- Если airspeed отсутствует → возвращаем текущую тягу с флагом `'reason': 'missing_airspeed'`
- Читаем `flaps_position`, `gear_down` из `telemetry['configuration']` (FLAPS_HANDLE_PERCENT, GEAR_POSITION)
- `.get()` для всех вложенных доступов

---

### MEDIUM — некритично но раздражающе/неоптимально

#### 4. Format string `"%s%"` в 4 местах — `ValueError: incomplete format`
- `modules/control.py:150` (Throttle set log — выполняется на каждом установке тяги)
- `modules/autothrottle.py:75` (Autothrottle activated)
- `modules/connection_optimizer.py:341` (Reliability log)
- `modules/approach_phases.py:473` (Stable autothrottle log)

**Симптом:** Каждый вызов → traceback `--- Logging error --- ValueError: incomplete format` в stderr. Сама throttle установка работает (строка ДО лог-вызова), но stderr захламлён.

**Фикс:** `"%s%"` → `"%.1f%%"`. Двойной `%%` экранирует литерал `%`.

#### 5. `modules/approach_phases.py:472` — `KeyError: 'is_stable'`
**До:** `if throttle_data['is_stable']:` — если autothrottle вернул dict без этого ключа (например на error path) → KeyError → выход в except в main loop → see fix #2.

**Фикс:** `if throttle_data.get('is_stable', False):`

#### 6. `modules/approach_phases.py:524-548` — SimConnect spam
**До:** Каждые 0.5s цикла на высоте < 2000ft и < 1500ft вызывались `set_flaps()` и `set_gear()` независимо от текущего состояния.

**Фикс:** Идемпотентность через флаги `_flaps_2_deployed`, `_flaps_3_deployed`, `_gear_deployed` в инстансе FinalPhaseState. SimConnect получает команду один раз, есть лог каждой деплоировки.

#### 7. `modules/stabilized_approach.py:85-95, 215-224` — Fragile dict access на критическом пути
**До:** Прямые `telemetry['speed']['airspeed_indicated']` и пр. — KeyError на missing data → выход в main except → see fix #2 (silent stop).

**Фикс:** Защищённое чтение через `.get()` с None-guards. Если airspeed отсутствует — пропускаем проверку (а не делаем ложный go-around).

#### 8. `modules/approach_phases.py:571-589` (LandingPhaseState) — Та же fragility на flare-критическом пути
**Риск:** Если altitude_agl = None → flare_controller.should_start_flare(None, ...) → math error → silent stop. Или хуже — None coerce в 0 → "мы на земле" → flare на 200ft.

**Фикс:** None-guards перед началом flare логики, ранний return если данные неполные.

---

## Не исправлено в этом батче (требует обсуждения)

### CRITICAL — нет
### HIGH (4):

1. **`modules/engine_failure_detector.py:114`** — TODO "Добавить реальное чтение из SimConnect". Сейчас читает из `telemetry['engines'][f'engine_{i}']` но `telemetry.py:get_all_data()` НЕ возвращает ключ `'engines'`. То есть детектор отказов всегда видит "все running, n1=0, oil_pressure=0" — может ложно сработать на исправном самолёте.

2. **`modules/navigation.py:212`** — `wind_factor = 1.0 - (headwind / ground_speed * 0.3)` без guard `ground_speed > 0`. Если самолёт на земле (ground_speed = 0) → ZeroDivisionError при расчёте distance prediction.

3. **`modules/aircraft_config_reader.py:33-37`** — Hardcoded Windows paths:
   ```
   r"C:\Users\Public\Documents\InstantSim\InstantSim\Packages",
   r"C:\Users\Public\Documents\Microsoft Flight Simulator\Packages",
   ```
   Сломается на нестандартной установке MSFS Steam. Нужно делать configurable.

4. **Threading state без локов** — обнаружен в 8+ модулях (autothrottle.active, autopilot_takeover.takeover_in_progress, stabilized_approach.go_around_required, etc.). GUI thread пишет stop_approach → main thread читает self.running. Race condition не критичен (флаги атомарны в Python), но `engine_failure_detector.engines` (dict) — не атомарный. Если detector обновляется из main thread пока GUI читает (для отображения) — может прочитать частичные данные.

### MEDIUM (~10):

- `modules/thresholds_config.py:175` — `json.load()` без try/except → если thresholds.json malformed, всё падает на init
- `aircraft_adapter.py:get_aircraft_info` — E-сложность 38 (рефактор через Strategy)
- `msfs_airport_reader.py:auto_configure_approach` — E-сложность 34
- `aircraft_config_reader.py:_detect_from_manifest` — E-сложность 33
- `gui.py` — 2481 строка монолита (split на panels/)
- `modules/airports_database.py` импортирует `modules.navigation` (нарушение слоёв — config не должен импортить бизнес-логику)
- `autothrottle` не имеет метода `update()` (architectural test FAIL)
- `connection_monitor.py:693` использует f-string в logger (lazy %)
- 245 проблем от prospector — many cosmetic
- Большинство f-string в logger вызовах (logging-fstring-interpolation) — performance cost когда уровень DEBUG отключён

### LOW: cosmetic, refactoring opportunities

---

## Что НЕ покрыто review (нужен flight test)

Все these untested code paths могут содержать ещё баги (ты не делал заходов в симуляторе):

- `approach_phases.py` — state transitions IDLE→INITIAL→INTERMEDIATE→FINAL→LANDING→GO_AROUND→COMPLETED
- `flare_controller.py` — pitch ramp 2.5°→6.0°, VS ramp 600→100 fpm
- `autothrottle.py` — PID на финале с реальной телеметрией
- `dme_navigation.py` — DME arc + altitude check at fixes
- `engine_failure_detector.py` — реальный отказ двигателя сценарий
- `wind_shear_detector.py` / `turbulence_detector.py` — на реальных данных
- `aileron_compensation.py` / `rudder_compensation.py` — асимметричная тяга на 2/3/4-engine
- `autopilot_takeover.py` — переход AP→manual на 1500ft

**Рекомендация после применения этих фиксов:** Сделай первый заход в симуляторе на TBM 930 на UUEE/JFK ILS и записывай логи. Я смогу проанализировать что пошло не так и где ещё баги.

---

## Список изменённых файлов

| Файл | +/- |
|--|--|
| `main.py` | +29/-9 |
| `modules/approach_phases.py` | +35/-15 |
| `modules/autothrottle.py` | +24/-6 |
| `modules/connection_optimizer.py` | +1/-1 |
| `modules/control.py` | +1/-1 |
| `modules/flare_controller.py` | +7/-5 |
| `modules/stabilized_approach.py` | +27/-10 |
| **Total** | **+143/-39** |
